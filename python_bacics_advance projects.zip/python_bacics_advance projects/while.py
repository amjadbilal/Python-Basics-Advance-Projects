def ufun():
    print("my name is unknown by you")
cond=10
while cond>0:
    ufun()
    cond -=1
    print(cond)   