travelLog=[
{
    'city_visits':3,
    'city_dist':'long',
    'bus':'niazi',
    'city_name':'islamabad',

}]
 
def add_new_Data(visited_time,covered_dist,newBus,cityNam):
    newDict={}
    newDict['city_visits']=visited_time
    newDict['city_dist']=covered_dist
    newDict['bus']=newBus
    newDict['city_name']=cityNam
    travelLog.append(newDict)
add_new_Data(10,'short','youtoung','lahore')    
print(travelLog)