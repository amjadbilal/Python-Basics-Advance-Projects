x='''hello how are your baby and 
what are you doing now  i am learning python since morning .
Do you want to learn python with me i will help you as i could
so fell free to jion me '''
print(x)

# length of a string 
my="this is my second day of learning python"
print(len(my))

you='start with the name of allah who has blesed me  more much'
print(len(you))

print(you[11])
print(you[-13])


# string in and not in operator

print('me' in you)
print('hell0' in you)
print('amjad' not in you)
print('allah' not in you)
print('ali' in you)
print('who' not in you)


#  Slicing in py

x='how are you guys'
print(x[4:9])

# print(x[2:6])
# print(x[3:11])
# print(x[0:16])

# print(x[:10])
# print(x[4:19])
# print(x[-5:16])

#  String concatination

a='foeaoaofhoiwear'
b='niafafvnavia'
print(a+b)

x='my name is amjad bilal' +'son of m arshad'
print(x)

# multiplication of string
# print(x*10)
# print(x*4)