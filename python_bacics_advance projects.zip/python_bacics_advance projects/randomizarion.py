import random 
rand_integer=random.randint(1,10 )
print(rand_integer)

# How to print a string randomly

my_str="names","class","room","home","chair","pencil","mouse","keyborad"
my_soo=random.choice(my_str)
print(my_soo)


# randomization of  float   number
rand_float=random.random()*5

print(rand_float)

love_score=random.randint(1,100)
print(f"Your love score is{love_score}")
 
luck_num=random.randint(1,200)
print(f"Your lucky number is {luck_num}")


