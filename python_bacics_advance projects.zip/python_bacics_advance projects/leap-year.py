year=int(input('put year'))
if int(year/4):
    print('Hello       ')