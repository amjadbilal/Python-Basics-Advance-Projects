#  Casting mean conversion of data types for example
# int int float
# float int0 int
# str into int 
# int into str 
# including all types of datatypea conversion

x = 20
print(float(x))

X=40
print(str(X))
y=423.23
print(int(y))
a=23
print(complex(a))

d="323442"
print(tuple(d))

D="8666868"
print(bool(D))

D=8666868
print(bytearray(D))

D=8666868
print(bytes(D))


D=8666868
print(BytesWarning(D))


D=8666868
print(range(D))

#  We cant add int into string  x=20 +"cbasbc" invalid
# But can add int into float and vice versa 

# Addition of int and floate
s=20 + 22.2
print(s)

S=32.4 -40
print(S)

# Deletion of a  vars
v=40
print(v)
del v
print(v)