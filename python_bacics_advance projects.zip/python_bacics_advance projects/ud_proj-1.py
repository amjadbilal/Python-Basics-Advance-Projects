greeting="wELCOME HERE DEAR NICE TO MEET you"
print(greeting)
city=input("Enter your birth city\n")
pet=input("put your pet name\n")
print("Your you are from " +city +"and your pet name is  "+ pet)
