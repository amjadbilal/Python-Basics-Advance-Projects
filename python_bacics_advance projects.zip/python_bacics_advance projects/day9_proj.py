 
import clear

bid={}
bidding_finished=False
while not bidding_finished:
    name=input('put your name') 
    price=input('your price')
    bid[name]=price
    shouldContinue=input('is there any other bidder '+ 'Yes or No')
    if shouldContinue=='no':
        bidding_finished=True
    elif shouldContinue=='yes':
        clear()
       
       
 


