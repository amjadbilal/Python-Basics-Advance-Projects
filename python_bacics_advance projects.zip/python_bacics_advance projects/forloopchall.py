# student_height=[102,190,220,180,150]
# for student in student_height:
#     # total_height=sum(student_height)
#     num_student=len(student_height)
#     avg=round(total_height/num_student)
# print(avg)

# for student in student_height:
# height =0
# for student_height in height:
#     student_height +=height
# print(student_height)

# How to find min and max value in a given list of numbers
# num=[10, 20, 30, 40, 50]
# print(max(num))

# print(min(num))


# using for loop to fund max or min value
student_score=float(input("put your scores here\n"))
heighest_score=0
for score in student_score:
    if student_score > heighest_score:
        heighest_score=score
print(f"your hieghest score is {heighest_score}")

