#   OPERATOR TYPES
# ARITHEMATIC
# x=23
# e=43
# z=43534
# w=x-e
# w=(x*e)+z-(x+e)+z
# print(w)

# print(w)
# print(x+e)
#ASSIGMENT
# x +=5783465
# x -=5783465
# x /=5783465
# x *=5783465
# print(x)
#               IDENTIY OPERATOR    (is not)
# 
# "Is" and "is not" are comparison operators in Python used to test if t    wo objects are the same or not.
# The "is" operator returns True if two objects have the same identity, i.e., they refer to the same object in memory. For example, a is b will return True if a and b refer to the same object.

# The "is not" operator returns True if two objects do not have the same identity, i.e., they do not refer to the same object in memory. For example, a is not b will return True if a and b do not refer to the same object.

# It's important to note that "is" and "is not" compare object identity, not object values. For comparing object values, you should use the comparison operators like == (equal to) and != (not equal to).

# ads="this content is about identity operator"
# print('operator'  in ads)
# print('huiuasduif' is not  ads)
# print('content' is ads)


# MEMERSHIP OPERATOR
ady="hello gus this side amjad bilal"
print('helll'  in ady)
print('hello'  in ady)
print('hello'  not in ady)