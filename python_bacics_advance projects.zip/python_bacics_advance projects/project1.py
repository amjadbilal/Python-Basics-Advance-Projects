city=input("whats your city name\n")
print(city)
capit=input("what is your capital name\n")
print("your city name is  " + city +" and your capital name is "+capit)


