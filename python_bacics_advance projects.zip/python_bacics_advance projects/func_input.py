# def myfunc():
#     name=input("enter your name\n")
#     age=input("put your age\n")
#     print(name +age)
# myfunc()    

# Functions with given inputs
# argument is the name of value 
# parameter is value 
# def good_name(name):
#     print(f"Welcome here Mr {name} ")
#     print(f"I am hopefull {name} you will do this")
 
# good_name("AMJAD BILAL  ")    

# def age(age):
#     ag=input("ag??\n")
#     print(f"i am not too old guy {age}")
#     print(ag)
# age("21")    


# def marks(numbers,name):
#     print(f"tell us your {numbers}")
#     print(f'your good name is {name}')
# marks('80','AMJAD')    

def soots(cotton, rysham,jeans):
    print(f"i like {cotton}")
    print(f'is your favourite {rysham}')
    print(f"i also uses{jeans}")
soots('silk','desi','jhony')    