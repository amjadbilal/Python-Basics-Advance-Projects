# my_name=" Hello " + input(' what is your name') +"!"
# print(my_name)
# age= "so you are " + input('enter your age') 

# print(age)

# degree="Mention your degree name" + input('you degree ?')
# semester="smester ?" + input('your semester ')
# print(semester)



def index_func():
    name=input('enter your name\n')
    age=input('how old you are \n')
    class_=input("class Name\n")
    print(name,age,class_)
index_func()









# mystr2="helo pytohn i am welcome here to learn you exelently"+"this is my second string for printing \n"+input("now enter your info ") 
# # print(mystr2)
# age=f"{mystr2}"+"this is second param"
# print(age)













