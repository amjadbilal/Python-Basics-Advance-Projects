# my_dict={
#     'name':['asad','ali','joe'],
#     'cast':['jutt','arain','randhawy'],
# }
# for thing in my_dict:
    
#  print(thing)
# for key in my_dict:
#  print(my_dict[key])
# my_dict['cast']=['watto','sandeela','jutt']
# print(my_dict)



# Dictionary inside dictionary
programmingDict={'Father':{
    'childs':['ahsan','ali','jhone','gundu']

},
'Relatives':['uncle','cousin','mother','sister']
}
# programmingDict['childs']='amjad'
for thing in programmingDict:
    print(thing)
print(programmingDict)