# prog_dictionaries={'functions':'this is my dict',
#                    'groups':'incude all blood groups haha',}
# print(prog_dictionaries)
 
my_dict={"names":['amjad ','aqdas','afzal']}


# print(my_dict)
# print(my_dict)

# for thing in my_dict:
#     print(thing)
# for key in my_dict:
#     print(key)
#     print(my_dict[key])


# for multi values
# traveling={
#     'bus':['ali express','niazi express'],
#     'stops':['lahore','shkp','fsbd'],
# }
# traveling["conductor"]="ali",'asad',


my_dicts={'name':'amjad s assignment','degree':'bscs'}
my_dicts['ag']='5912'

# print(my_dicts['degree'])
# print(my_dicts['Key'])
my_dicts['Assignment']='amjad s assignment'
my_dicts['Assignment']="hello"
# print(my_dicts)
# for thing in my_dicts:
#     print(thing)
for key in my_dicts:
    print(key)
    print(my_dicts[key])

 