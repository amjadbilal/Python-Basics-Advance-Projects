# Methods to define programming_Dictionary

programming_Dictionary={'Function':'how are you dear'}
# print(programming_Dictionary)

# Second method 
dictionaries={'age':'this is second method to define programming dictionaries',
'class':'this is not my class',              }
# print(dictionaries)

dictionaries["func"] = 'this topic is all about dictionaries '
# print(dictionaries)

# Edit in dictionary 
dictionaries['webster']='this is voice of a webster'
# print(dictionaries)

# for thing in dictionaries:
#     print(thing)

# method to access all value of 
for key in dictionaries:
    print(key)
    print(programming_Dictionary[key])