import random
coin='''
(_________)
____, __'''
scissor='''
(__________)


_____'''
user_choice=input('what do you want to select, Type 0 fro Rock , 1 for Paper, 2 fro Scissor \n')
computer_cal=random.randint(0,2)
print(f" computer choose {computer_cal}")
