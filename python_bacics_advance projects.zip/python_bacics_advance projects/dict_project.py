student_scores={
  'ali':98,
  'asad':89,
  'ahmad':78,
  'jhon':68,
} 

student_grades={}
for student in student_scores:
  scores=student_scores[student]
  if scores > 90:
    student_grades[student]="Outstanding"
  elif scores > 80:
    student_grades[student]="Exeeds Expactations"
  elif scores > 70:
   student_grades[student]='Acceptable'
  else:
    student_grades[student]='Fail'
    print("fail")
print(student_grades)