:
    print(thing)
for key in my_dict:
    print(key)
    print(my_dict[key])