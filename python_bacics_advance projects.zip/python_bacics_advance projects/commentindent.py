print("WELCOME TO HERE IN PYTHON ENVIRONMENT")
print("Start with name of allah")
print("welocome to here Mr AMJAD BILAL")

# Comment & indentaion in  python
 # this is how to comment multilines in python

''' lorem20 this is word collection 
 lorem20 this is word collectionlorem20 this is word collection
 lorem20 this is word collection
 lorem20 this is word collection
 lorem20 this is word collection '''
 # what is indentation in python
'''in python all lines should be start from same sepquence
 In short it mean any error due to spaces in python'''
 