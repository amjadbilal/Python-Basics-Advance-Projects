height=input(input("what's your height\n"))
if height>=120:
 print("you can ride")
 age=input(input("what's your age\n"))
 if age>18:
  print("you have to pay 18$")
 elif age<=18:
  print("you have to pay 15$")
 else:
  print("pay 5$")
else:
 print("you have to grow your self")  
