# height=int(input("enter the height of the wall\n"))
# width=int(input("width of wall\n"))
# paint=(height*width)/5
# print(round(paint))


import math
test_h=int(input("enter wall height\n"))
test_w=int(input("enter wall width\n"))
coverage=5
def names_of_params(height,width,cover):
    area=height*width
    num_of_cans=math.ceil(area/cover)
    print(f"the number of {num_of_cans} you will be needed")
names_of_params( height=test_h ,width=test_w, cover=coverage)    
