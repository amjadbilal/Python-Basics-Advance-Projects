# Short jand if is only valid for single line body
if 10>2: print("this is valid logic")

#  If you want to use if body later we use pass function
# if 50>20:
#     pass
# else:
#     print("this is not valid")

    # Short Hand if Else
print("i hat you ") if 21>22 else print("i have set my mind to become an efficient developer .Dont disturb anybody life ")


# Calculator
val=int(input("enter first integer  "))
val3=input("enter an operand")
val2=int(input("enter second integer   "))
# op='+'
# op='*'
# op='-'
# op='/'
if val3=='+':
    print(val+val2)
elif val3=='-':
    print(val-val2)
elif val3=='/':
    print(val/val2)
elif val3=='*':
    print(val*val2)