# var is defined as these are electricals memory locations that stores its value
# A-Z, a-z, 0-9_ 
# 1age this is not valid method in python



#  this is Camel  case var defining method   myWeb, yourName, myFirstWeb
# this is Snake case var defining method      my_web, your_name, my_first-web
# Pascal var defining method    MyWeb, YourName, MyAge 
age=20
_smes=4
table=30
table2=40
c=age+_smes+table+table2
print(c)
print(type(table))
#  py is case sensitive language
# x=39
#  X=32
# both x values are not same in python these are considered differently
mouse=2.8
notepad=99.99
lock=notepad*mouse
print(lock)
print(type(notepad))

# how to navigate data type
# this is complex type
me=4j
print(type(me))
you=20.888
print(type(you))
he=344.2
hello=3212.1
print(type(hello))
double=30.0
print(type(double))


# same values can be defined multi vars
x = y = z =30
a=x+y+z
print(a)

AmjadBilal = Aqdas = Ali = 7
c=AmjadBilal/Aqdas/Ali
print(c)

# One to One Maping 
x,z,a=100,200,400
b=a-z-x
print(b)
print(type(b))

Name="MUHAMMAD AMJAD BILAL"
print(type(Name))

