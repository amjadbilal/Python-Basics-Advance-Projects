wght=5
item='sugar'

my_str='i want to pruchase {} kg {}'
print(my_str.format(wght,item))

qoute=30
criteria=80
wow='selected'
my_str1='if you are above {} having {} grades then congrates you are {}'
print(my_str1.format(qoute,criteria,wow))

# op='bold man'
# status='continue'
# my_str3='if you are {1} and learning process is  {0} then we hope you well be successful soon inshallah'
# print(my_str3.format(op,status))


# Escaping in python
s1='i am begginer in python  \'wow!\''
print(s1)
s2='i am begginer \n in python \t \'wow!\''
print(s2)


a2="my name is amjad bilal"
print(a2.upper())
a1="!! AMJAD BILAL! "
print(a1.replace("AMJAD BILAL","JHONE"))
print(a1.upper())
print(a1.strip("!"))

q="MY BEST HELPER IS MY ALLAH HE NEVER LEFT ME ALONE IN ANY DELLIMA"
print(q.lower())
# print(a1.capitalize())
# print(a1.casefold())
# print(a1.encode())
print(a1.encode())
# print(a1.zfill())
print(a1.rstrip("!"))
