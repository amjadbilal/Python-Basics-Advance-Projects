cars=['honda','civic','bugati cheron']
for car in cars:
    print(car)
    print(car +'\n mercidy')
print(len(cars)) 

