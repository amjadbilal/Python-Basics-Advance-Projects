# def myAge():
#     input("enter your age\n")
#     input(len("enter your age\n"))
#     print(type("65"))
#     print(type("34"))
# myAge()
 
# def my_info():
#     name=input('Enter your name\n')
#     age=input("yor age??\n")
#     F_name=input('Your F name\n')
#     print(name+age+F_name)
# my_info()    

def myfun():
    print(type(75))
    print(len("welcome here mr amjad bilal"))
    print(input("put your name\n"))
myfun()    