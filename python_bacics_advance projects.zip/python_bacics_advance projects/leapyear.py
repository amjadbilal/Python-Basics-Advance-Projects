height=int(input("put your height\n"))
if height>=120:
    pass
else:
    print("you are not eligible")

age=int(input("put your age\n"))
if age==7:
    print("please pay 7$")
elif age<=18:
    print("pay 10 $")
else:
    print("pay 18$")

    

