# IndexError: list index out of range
# To solve above error we find below solution
 
alphbets=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
direction=input("type encode to encrypt and type decode to decrypt\n")
text=input('type your message here \n').lower()
shift=int(input('Type the shift number\n'))

def decrypt(cipher_text,shift_amount):

    plain_text=''
    for letter in cipher_text:
        position=alphbets.index(letter) 
        new_position=position-shift_amount
        new_letter=alphbets[new_position]
        cipher_text +=new_letter
    print(f'the encoded code is {plain_text}')    

decrypt(cipher_text=text,shift_amount=shift)
    


