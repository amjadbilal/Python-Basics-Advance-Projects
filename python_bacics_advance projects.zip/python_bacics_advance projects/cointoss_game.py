import random

coin=random.randint(1,2)
if coin==2:
    print(f"Head")
else:
    print("Tail")

