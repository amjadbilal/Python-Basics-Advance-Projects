# x= 1
# while x<=20:
#     print("After While loop")
#     x=x+1
    

# x=10
# while x<100:
#     print('YOU CAN DO EVERYTHING AMJAD BILAL .DO YOU WANT TO BECOME A WELL WISHED PERSON ')
#     x=x+5

#     print(' you can do everything do you want amjad bilal')


    # WHILE LOOP PRACTICE SET
#  Write  a program to sum all number uptill 100
# y=1
# while y<=100:
#     print(y)
#     y=y+5
# else:
#     print('this is else condition')

# write a program to print  all the even numbers between 1 to 100 using while loop
num=2
while num<=100:
    print(num) 
    num=num+2
    
# write  a program to print all alphabets except vowels
    
