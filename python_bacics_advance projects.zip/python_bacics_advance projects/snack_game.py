from turtle import *
from random import randrange
from freegames import square,vector
food=vector(0,0)
snake=[vector(10,0)]
aim=vector(0,10)


