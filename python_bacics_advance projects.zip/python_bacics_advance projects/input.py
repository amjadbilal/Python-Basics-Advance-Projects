name=input('enter your good name  ')
age=int(input('enter your age '))
clas=input('enter your class ')
education=input('your  education')
f_name=input('Guardian name')
print(f"Your name is {name} ,your age is {age} , your current clas{clas}, your education is {education}, your guargian name is{f_name}")
print('Did you put exact info')
confirm=input('?  :')

