mydict={"Outer":{"Inner":900}}
print(mydict)
print(mydict["Outer"]["Inner"])
print(mydict.items())
# Another Method To express
secDict={"key1":100,"key2":200,"key4":500}
print(secDict.keys())
print(secDict.values())
print(secDict.items())
