weight=int(input("enter your weight\n"))
height=int(input("put your height"))
bmi =round(weight/height ** 2)
if bmi< 18.5:
    print(f"you {bmi} under weight")
elif bmi<25:
    print(f"Normal {bmi}, weight")
elif bmi>=30:
    print(f"your "+ {bmi}+" Overweight")
elif bmi<=35:
    print(f" your {bmi},obsed")
else:
    print("you are {bmi}, clinically obsed")
