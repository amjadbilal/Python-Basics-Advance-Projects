height=(int(input("put your height\n")))
if height>=120:
    print("you are eligible for ride")
    age=(int(input("enter your age\n")))
    if age<18:
        print("you are not selected")
    elif age<=35:
        print("Congrates ! you are selected ")
    else:
        print("try later")
else:
    print("Sorry you are not eligible for riding")
