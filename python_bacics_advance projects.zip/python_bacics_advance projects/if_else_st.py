if 5>2:    
    print("this is true")
else:
    print("false")

if int(input("enter a number")) >9:
    print("excellent")
else:
    print("not good")
    
    