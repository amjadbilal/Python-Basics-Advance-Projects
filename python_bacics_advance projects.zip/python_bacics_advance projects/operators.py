



# Operators   in py 
# Arithematic operator
# Logical Operator
# Comparison Operator
# Bitwise op
# Assignment Operator
# Identity Operator
# Membership Operator
# // is floor division
# x**y is exponentional form (form of power) 



# x=20
# y=40
# z=x/y
# z1=x//y
# z=x+y
# z3=x-y
# z4=x*y
# z5=x**y
# print(z4)
# print(z3)
# print(z)

# print(z1)
# print(z)
# print(z5)

#  Comparison Operator
# x1=100
# q2=200
# print(x1>q2)
# print(q2>x1)
# print(x1>=q2)
# print(x1!=q2)
# print(x1==q2)
# print(q2>=x1)
# Logical Operators
# And operator
a=40
s=50
z=90
print( a < s  and z < 100)
print(z >a and s !=50)
print(a > z and s <20)
print(a > z and s <20)
print(True and True)
print( False and True)
print(True and True)


# Or Operator 
X=50
Z=30
A=90
Q=100
print( X > Z or A < Q)
print(X <Z or Q < X)
print( A > Z or  X < 100)





# Not operator

s=20
d=10
c=40
print( s != c)
print (d < s == 40)
print(c> s !=d)


# Comparison Operator 
x=40
s=39
d=20
print(x<=s )
print(s>=d )
print(x==s==d)
print(x!=s!=d)
print(x>s>d)

# Assignment Operator
x=50
y=30
x -=y
print(x)

x +=60
print(x)
y *=550
print(y)
x /=10
print(x)
y %=5
print(y )

x **=4
print(x)

y //=5
print(y)

#  Identity operator 
# is and is not are the identity operators are used to check  if two  values are  located on the same part of memory laocation

x=100
y=100
print(x is y)  
print(x is not y)
x= 23
y=23
print(x is y)
print(x is not y)

#                   Membership operator 
# in and not in are membership operators used to check werther a sequence is presented in an object or not
# x='my name is amjad bilal '
# print( 'bilal' in x)
# print('my' is not x)

# d='my effort are going well '

# print('effort' in d )
# print('effort'  not in d )