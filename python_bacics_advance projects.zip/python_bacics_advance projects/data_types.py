'''
7 types of data exist 
numbers
bools
list
string
tuple
set 
dictionary'''

# print(4>5)
 
# print(90>30)

# x= True
# print(x)

# tuple data type 

# y='allah ','muhammad','i love '
# print(tuple(y))

# print(5>4==4<5)
# a=5
# b=4
# print(type(a>b==b<a))


# X='allah '+'muhammad'   +'  i love '
# print(X)
# print(type(X))
# name="ali   "
# name=(234,3453,232)
# name=32
# age=34
# print(type(age))
# fellows=['umer','jawad','waqas']
# print(type(fellows))
x=23
u=343
c=x<u
print(c)
