# myname=input("put name\n")
# print(myname)
# print('Welcome here Mr.'+ myname +"\nWelocme for coming back")
# Above whole process in single line
print("so you are here "+ input("Please tell me your name\n") +"Welcome here Mr .")