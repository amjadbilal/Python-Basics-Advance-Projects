#  how to separate str or strings in python
x,y ,z = 20, 40, 50
print(x,y,z ,('how easy this python language'))

print('hello how are u',   'me fine and you')
print('AMJAD BILAL', 'AQDAS', 'M.ARSHAD' , sep='--')
print('AMJAD BILAL', 'AQDAS', 'M.ARSHAD' , sep='__')
print('AMJAD BILAL', 'AQDAS', 'M.ARSHAD' , sep='!!!!!')
print('AMJAD BILAL', 'AQDAS', 'M.ARSHAD' , sep='$$$')
print('AMJAD BILAL', 'AQDAS', 'M.ARSHAD' , sep='&&')


#  how to get output in single line 

print("oaoifawo", "allah is ine" ,end='==')
print('this is good working time')

#Another  methode to connecting tow params
MyName="AMJAD BILAL"
age=21
location="pakistan"
print('Myname is',MyName,"Watto",'and','age is',age,'and i live in',location)

#  STRS CONCATINAION 
hello="how are ou"
me='alhamdullilah i am fine'
print(hello,me)
print('how are ou',end=' & ' +'alhamdullilah i am fine', sep='==')
name='AMJAD BILAL'
age=21
cgp=3.33
# print('my name is' +name +' and my age is '+str(age)+ 'my cgpa of 4 semeters is '+ str(cgp) +'now i am trying my best to learn python')
print(f'my name is {name} and my age is +str{age} my cgpa of 4 semeters is str{cgp}now i am trying my best to learn python')
