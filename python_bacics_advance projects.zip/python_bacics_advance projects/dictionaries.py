Teacher={"name":"AMJAD","age":"21","education":"BSCS"}
print(Teacher["name"])

uni={"area":"75 acre", "rank":"Normal","student_strength":3300}
print(uni)
print(uni['rank'])
# Updation 
uni["length"]="2km"
print(uni)
# Easy Way to update any existing data

employees={"salary": "200$", "age":"30","nationality":"PAKISTANI"}
employees["sweeper"]="Jhone"
print(employees)
print(employees['nationality'].lower())


#  Another an efficient method of data listing, data dictionary etc.
stock={"medicines":[200,400,600,900],"tablest":[10,20,30]}
stock["injections"]="nerobian"
# print(stock)
# To check the history of single attribute from lot of butes
# use istory word 
history=stock["medicines"]
print(history)
print(f"Show me history of medicines:{history[2]}")

print(f":{history[3]}")

myBook={"pages":"12","colors":"blue","wight":"1pound"}
print(myBook["pages"])
print(myBook)
print(myBook.keys())
print(myBook.values())




