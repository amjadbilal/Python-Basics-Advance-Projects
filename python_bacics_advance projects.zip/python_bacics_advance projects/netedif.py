marks=int(input("enter your marks first\n"))

if marks >=90: 
    print("your grade is A+ ")
elif marks>80:
    print("your grade is A ")
elif marks >=65:
        print("your grade is B ")
elif marks>=55:
        print("your grade is C")
elif marks>=40:
            print("your grade is D")
else:
            print("you are failed")
