row1=["instagram.png" ,"instagram.png","instagram.png"]
row2=["instagram.png" ,"instagram.png","instagram.png"]
row3=["instagram.png" ,"instagram.png","instagram.png"]
map=[row1,row2,row3]
print(f"{row1}\n{row2}\n{row3}")
position=input("where do you want to palce your horse")

