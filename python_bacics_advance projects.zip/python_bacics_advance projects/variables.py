# classes=390
# if classes==390:
#     print ('True')
# else:
#     print('flase')
     
    #  Variable declaration 
# askMe=input('your age')
# print(askMe)


_myage=input("put your age\n")
print(type(_myage))
print(len(_myage))

helpHope=748758485843
print(helpHope)



