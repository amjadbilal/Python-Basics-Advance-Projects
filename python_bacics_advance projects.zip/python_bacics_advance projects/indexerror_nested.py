#  This exercise is especially for solving index out of range error as it starts from 0 index

my_str="names","class","Room","home","chair","pencil","mouse","keyborad"
print(my_str[0])
print(len(my_str))
print(my_str[7])
print(my_str[5])

# print(my_str)


# Nested list or how to print a list inside a list 
fruits=["apple","bnana","mango","pineapple",'orange',"guawa","watermillon","peach","dates"]
vegitables=["potato","tomato","ginger","cocumber",]
print([fruits,vegitables,[6]])
