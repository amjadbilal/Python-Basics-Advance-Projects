from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.


# Contact Us Model 

class Contact(models.Model):
    name=models.CharField(max_length=122)
    email=models.EmailField(max_length=122)
    phone=models.IntegerField()
    desc=models.CharField(max_length=122)
    desc=models.CharField(max_length=122)
    date= models.DateField()
    def __str__(self):
     return self.name
    def __str__(self):
     return f"{self.name} ,{self.phone},{self.desc},{self.date}"
 
class Employees(models.Model):
  name=models.CharField(max_length=122)
  email=models.CharField(max_length=122)
  phone=models.IntegerField()
  education=models.CharField(max_length=122)
  age=models.IntegerField(validators=(MinValueValidator(0),MaxValueValidator(120)))
  heartrate=models.IntegerField(default=60,validators=[MinValueValidator(1)])