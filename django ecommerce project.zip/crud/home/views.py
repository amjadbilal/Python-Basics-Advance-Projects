from django.shortcuts import render, HttpResponse
from datetime import datetime
from django.contrib import messages
from home.models import Contact
# Create your views here.
def index(request):
    # messages.success(request,"this is test message")
    return render(request,"index.html")
def contact(request):
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact=Contact(name=name, email=email,phone=phone,desc=desc,date=datetime.today())
        contact.save()
        messages.success(request, "Your message ha been sent successfully.")
        # all_contact=models.contact.objects.all()
        # context={'contact':all_contact}
        # return render(request,"contact.html",context=context)
        return render(request,"contact.html" )
def about(request):
    return render(request,"about.html")
def product(request):
    return render(request,'product.html')

def register(request):
    return render(request,'register.html')

def register1(request):
    return render(request,'register1.html')

 
 

# messages.debug(request, "%s SQL statements were executed." % count)
# messages.info(request, "Three credits remain in your account.")
# messages.success(request, "Profile details updated.")
# messages.warning(request, "Your account expires in three days.")
# messages.error(request, "Document deleted.")