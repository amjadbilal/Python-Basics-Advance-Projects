from django.contrib import admin
from  home.models import Contact
from  home.models import Employees
# Register your models here.
admin.site.register(Contact)
admin.site.register(Employees)