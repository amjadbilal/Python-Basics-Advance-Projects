  

from django.urls import path
from home import views
urlpatterns = [
     
    path('',views.index, name='home'),
    path('index',views.index, name='index'),
    path('contact',views.contact, name='contact'),
    path('about',views.about,name='about'),
    path('product',views.product,name='product'),
    path('register',views.register, name='register'),
    path('register1',views.register1, name='register1'),
    
    
    
]
